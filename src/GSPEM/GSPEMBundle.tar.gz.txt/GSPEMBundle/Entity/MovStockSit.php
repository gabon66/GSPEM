<?php

namespace GSPEM\GSPEMBundle\Entity;

/**
 * MovStockSit
 */
class MovStockSit
{
    /**
     * @var int
     */
    private $id;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
}
